package com.example.cafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
